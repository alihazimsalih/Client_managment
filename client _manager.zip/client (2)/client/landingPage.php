<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="layout/css/bootstrap.min.css"/>

    <!-- fontawesome CSS-->
    <link rel="stylesheet" href="layout/css/all.min.css"/>
    <link rel="stylesheet" href="layout/css/fontawesome.min.css"/>

    <!-- My CSS -->
    <link rel="stylesheet" href="layout/css/landingPage.css"/>

    <title> Landing Page </title>

</head>

<body>

  <!-- Landing page -->
<body>
    <div class="container">
        <header class="head my-3">
          <!-- Start navbar for landing page -->
            <nav class="navbar navbar-expand-lg navbar-light head__custom-nav">
                <a class="navbar-brand d-flex align-items-center" href="landingPage.php">
                    <img src="layout/images/logo.svg" alt="website logo">
                    <span> Client Management</span>
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
                    <span> <img src="layout/images/menu.svg" alt="button menu" /></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="#">Help</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="sign.php">Sing in</a>
                        </li>

                    </ul>
                </div>
            </nav>
            <!-- End navbar for the landing page -->
        </header>
    </div>

    <div class="container">
       <div class="row custom-section d-flex align-items-center">
            <div class="col-12 col-lg-4">
                <h2>Client</h2>
                <h3>Management</h3>
                <p>
                  This application manages clients, from information on the client and content the MAPs and displays the client details and can update or delete the information
                </p>
                <a href="sign.php">Start App</a>
            </div>
            <div class="col-12 col-lg-8">
              <img src="layout/images/landingPage.svg" alt="Team process banner">
            </div>
        </div>
      </div>
     <!-- Optional JavaScript -->
     <!-- jQuery first, then Popper.js, then Bootstrap JS -->
     <script src="layout/js/jquery-3.5.1.min.js"></script>
     <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
     </script>
     <script src="layout/js/bootstrap.min.js"></script>
  </body>
</html>
