-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 16, 2020 at 11:54 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `client_manager`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `UserId` int(11) NOT NULL COMMENT 'Auto counter User id ',
  `UserName` varchar(255) NOT NULL COMMENT 'The user name for admin',
  `Email` varchar(255) CHARACTER SET utf8 COLLATE utf8_danish_ci NOT NULL COMMENT 'The email for admin',
  `Password` varchar(255) NOT NULL COMMENT 'The password for admin',
  `RegistrationDate` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'The registration date for admins'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`UserId`, `UserName`, `Email`, `Password`, `RegistrationDate`) VALUES
(4, 'ali', 'a@gmail.com', '123', '2020-08-16 21:01:31');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `FullName` varchar(255) NOT NULL,
  `PhoneNo` int(11) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Location` varchar(255) NOT NULL,
  `DeviceType` varchar(255) NOT NULL,
  `NearestPoint` varchar(255) NOT NULL,
  `PageName` varchar(255) NOT NULL,
  `UsersNo` int(11) NOT NULL,
  `Image` varchar(255) NOT NULL,
  `Description` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `FullName`, `PhoneNo`, `Email`, `Location`, `DeviceType`, `NearestPoint`, `PageName`, `UsersNo`, `Image`, `Description`) VALUES
(1, 'Ali Hazim ', 2147483647, 'ali.hazim.salih@gmail.com', 'Bagdadad', 'iphone', 'mashtal', 'house', 21, '', 'dsa');

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `id` int(11) NOT NULL COMMENT 'The id for the note',
  `title` varchar(255) NOT NULL COMMENT 'The title pf the note',
  `description` varchar(1024) NOT NULL COMMENT 'The description of the note',
  `creat_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`UserId`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `UserId` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Auto counter User id ', AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'The id for the note', AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
