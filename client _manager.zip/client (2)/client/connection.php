<?php 

    class Connection{

        public PDO $pdo;

        public function __construct(){

            $this->pdo = new PDO ('mysql:server=localhost;dbname=client_manager','root','');
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }

        public function getNotes(){
            $statment = $this->pdo->prepare('SELECT * FROM notes ORDER BY creat_date DESC');
            $statment->execute();
            return $statment->fetchAll(PDO::FETCH_ASSOC);
        }

        public function addNote($note){

            $statment = $this->pdo->prepare('INSERT INTO notes (title, description, creat_date)
                                           VALUES (:title,:description,:date)');
            
            $statment->bindvalue('title', $note['title']);
            $statment->bindvalue('description', $note['description']);
            $statment->bindvalue('date', date("Y-m-d H:i:s"));

            return $statment->execute();
        }

        public function getNoteById($id){
            $statment =$this->pdo->prepare("SELECT * FROM notes WHERE id =:id");
            $statment->bindvalue('id',$id);
            $statment->execute();
            return $statment->fetch(PDO:: FETCH_ASSOC);
        }

        public function updateNote($id,$note){
            $statment = $this->pdo->prepare("UPDATE notes SET title = :title, description = :description WHERE id = :id");
            $statment->bindvalue('id',$id);
            $statment->bindvalue('title', $note['title']);
            $statment->bindvalue('description', $note['description']);
            return $statment->execute();

        }

        public function removeNote($id){

            $statment =$this->pdo->prepare("DELETE FROM notes WHERE id =:id");
            $statment->bindvalue('id',$id);
            $statment->execute();

        }

    }

    return new Connection();
?>