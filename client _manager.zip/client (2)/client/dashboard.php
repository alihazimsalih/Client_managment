<?php

  session_start();

  if (isset($_SESSION['Username'])){

    $pageTitle = "Admin";

   include "initialize.php";
   
  } else{
      header('Location : index.php');
      exit();
    }

?>
