<?php 

    session_start();
    $do=isset($_GET['do']) ? $_GET['do']:'Manage';
    $pagetitle=$do." Clients";
    include 'initialize.php';
    if($do=='Manage')
    {
    
?>

<!-- tittle-->
<h1 class="text-center "><span> <img src="layout/images/manage.svg" class="image"/></span> Clients Management </h1>

<div class="container">
  <div class="row">
    <div class="col-sm">
      <a href="clients.php?do=Add "class="btn btn-success"><i class="fa fa-plus add-i"></i>Add New Client</a>    </div>
    <div class="col-sm">
    </div>
    <div class="col-sm">
       <form class="form-inline" action="clients.php" method="post">
         <input class="form-control " name="search_name" type="search" placeholder="Search" aria-label="Search" autocomplete="off">
         <button class="btn btn-outline-success"  name="search" type="submit">Search</button>
        </form> 
    </div>
  </div>
</div>
<!-- Client manage -->
<!-- tittle-->

<!-- search client -->

<!-- add new client , table client , controls -->
<div class="container">    
    
    
    <!-- start table -->
    <div class="table-responsive">
        <table class="main-table  table text-center table-bordered table-header">

                <tr>
                    <td> ID </td>
                    <td> Full Name </td>
                    <td> Phone Number </td>
                    <td> Control </td>
                </tr>

        </table>

        <div class="t-body">
            <table class="  table text-center table-bordered table-body ">   
              
              <?php
                // show clients depend on search.
                 $rows=getAll("*","clients","","","FullName","ASC");
                 if(isset($_POST['search'])) {  
                            
                     $search=$_POST["search_name"];
                     $stmt=$connectDb->prepare("SELECT * FROM clients WHERE FullName LIKE '$search%' OR PhoneNo LIKE '$search%' OR NearestPoint LIKE '$search%' ");
                     $stmt->execute();
                     $clients=$stmt->fetchAll(); 
                               
                     foreach($rows as $r){
                    // counter to count rows that equals the searched value
                      $i=0;
                          if($search!="") {
                                     
                            foreach($clients as $client){     

                                if($client['FullName']==$r['FullName']){          
                                    $i++;          
                                 }
                            // if row value equals the searched value add hover class
                            } if($i>0){
                                
                                echo"<tr class='hover'>";  
                                echo"<td>".$r['id'] ."</td>";
                                echo"<td>".$r['FullName'] ."</td>"; 
                                echo"<td>".$r['PhoneNo'] ."</td>";
                               
                                // Buttons controls
                                echo"<td> 
                                <a href='clients.php?do=Edit&clientid=".$r['id']."'class='btn btn-success'><i class='fa fa-edit'></i>Edit</a>
                                <a href='clients.php?do=Delete&clientid=".$r['id']."'class='btn btn-danger confirm'  ><i class='fa fa-close'></i>Delete</a>
                                <a href='clients.php?d=Information&clientid=".$r['id']."'class='btn btn-Info'><i class='fa fa-info'></i>Show Info</a>";
                                echo  "</td>";

                                echo"</tr>";

                              } else{
                                    echo"<tr>";  
                                    echo"<td>".$r['id'] ."</td>";
                                    echo"<td>".$r['FullName'] ."</td>"; 
                                    echo"<td>".$r['PhoneNo'] ."</td>";
                                    echo"<td> 
                                    <a href='clients.php?do=Edit&clientid=".$r['id']."'class='btn btn-success '><i class='fa fa-edit'></i>Edit</a>
                                    <a href='clients.php?do=Delete&clientid=".$r['id']."'class='btn btn-danger confirm'  ><i class='fa fa-close'></i>Delete</a>
                                    <a href='clients.php?d=Information&clientid=".$r['id']."'class='btn btn-Info'><i class='fa fa-info'></i>Show Info</a>";
                                    echo  "</td>";
                                    echo"</tr>";
                                  }
                                      
                                         
                                } else{
                                        echo"<tr>"; 
                                        echo"<td>".$r['id'] ."</td>";
                                        echo"<td>".$r['FullName'] ."</td>"; 
                                        echo"<td>".$r['PhoneNo'] ."</td>";
                                        echo"<td> 
                                        <a href='clients.php?do=Edit&clientid=".$r['id']."'class='btn btn-success'><i class='fa fa-edit'></i>Edit</a>
                                        <a href='clients.php?do=Delete&clientid=".$r['id']."'class='btn btn-danger confirm'  ><i class='fa fa-close'></i>Delete</a>
                                        <a href='clients.php?d=Information&clientid=".$r['id']."'class='btn btn-Info'><i class='fa fa-info'></i>Show Info</a>";
                                        echo  "</td>";
                                        echo"</tr>";
                                    }   
                                }
                            
                        } else{ // Show all clients
                            foreach($rows as $r){

                         echo"<tr>";
                         echo"<td>".$r['id'] ."</td>";
                         echo"<td>".$r['FullName'] ."</td>"; 
                         echo"<td>".$r['PhoneNo'] ."</td>";
                         echo"<td> 

                         <a href='clients.php?do=Edit&clientid=".$r['id']."'class='btn btn-success col-sm-2-offset'><i class='fa fa-edit'></i> Edit </a>
                         <a href='clients.php?do=Delete&clientid=".$r['id']."'class='btn btn-danger confirm'  ><i class='far fa-trash-alt'></i> Delete </a>
                         <a href='clients.php?do=Information&clientid=".$r['id']."'class='btn btn-Info'><i class='fa fa-info'></i> Show Info </a>";

                         echo  "</td>";
                         echo"</tr>";
                         }

                        }
                        ?> 
            </table>
        </div>
    </div>
    <!-- table end -->
</div>
 <!-- manage page end -->

        <?php
    /*
     Show Informations 
   */

}elseif($do=="Information")
{
    $clientid=isset($_GET['clientid'])&&is_numeric($_GET['clientid'])? intval($_GET['clientid']):0;  
    $row=getItem("*","clients","WHERE id={$clientid}","");
    if(count($row)>0)
    {?>
        <div class="container">
            <div class="information-header mx-auto">
            <h3>Information</h3>
            </div>    
            <div class="information mx-auto">
            <div class="row">
                   
                    <i class="fa fa-user"></i> 
                    <div class="col-md-2 col-sm-2">       
                        
                        <h5 class="lable">Full Name: </h5>
                       
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <h5 ><?php echo $row['FullName']?></h5>
                       
                    </div> 
                  
                    <i class="fa fa-phone"></i> 
                    <div class="col-md-2 col-sm-2">
                        
                        <h5 class="lable">Phone No: </h5>
                       
                    </div>
                    <div class="col-md-3 col-sm-6 ">
                        <h5 ><?php echo $row['PhoneNo']?></h5>
                       
                    </div>                  
                </div>
                <div class="row">
                   
                   <i class="fas fa-envelope"></i> 
                   <div class="col-2">       
                       
                       <h5 class="lable">Email: </h5>
                      
                   </div>
                   <div class="col-3">
                       <h5 ><?php echo $row['Email']?></h5>
                      
                   </div> 
                 
                   <i class="fas fa-map-marker-alt"></i>
                   <div class="col-2">
                       
                       <h5 class="lable">Location: </h5>
                      
                   </div>
                   <div class="col-3">
                       <h5 ><?php echo $row['Location']?></h5>
                      
                   </div>                  
               </div>
               <div class="row">
                   
                   <i class="fas fa-server"></i>       
                   <div class="col-2">       
                       
                       <h5 class="lable">Device Type: </h5>
                      
                   </div>
                   <div class="col-3">
                       <h5 ><?php echo $row['DeviceType']?></h5>
                      
                   </div> 
                 
                   <i class="fas fa-map-marked-alt"></i>
                   <div class="col-2">
                       
                       <h5 class="lable">Nearest Point: </h5>
                      
                   </div>
                   <div class="col-3">
                       <h5 ><?php echo $row['NearestPoint']?></h5>
                      
                   </div>                  
               </div>
               <div class="row">
                   
                   <i class="fas fa-map-marker-alt"></i>   
                   <div class="col-2">       
                       
                       <h5 class="lable">Page Name: </h5>
                      
                   </div>
                   <div class="col-3">
                       <h5 ><?php echo $row['PageName']?></h5>
                      
                   </div> 
                   <i class="fas fa-users"></i>     
                   <div class="col-2">
                       
                       <h5 class="lable">Users No: </h5>
                      
                   </div>
                   <div class="col-3">
                       <h5 ><?php echo $row['UsersNo']?></h5>
                      
                   </div>                  
               </div>
               <div class="row">
                   
                  <i class="fas fa-list-alt"></i>
                   <div class="col-2">       
                       
                       <h5 class="lable">Description: </h5>
                      
                   </div>
                   <div class="col-8">
                       <h5><?php echo $row['Description']?></h5>
                      
                   </div> 

               </div>
           
            </div>
  
        </div>     
    
 
   <?php 
   }
  }  
  /*
    Add  new clients
  */
   elseif($do =='Add'){
    
    $fullname=$phoneno=$email=$location=$devicetype=$nearestpoint=$pagename=$usersno=$description=$name="";  
    $fullname_error=$phoneno_error=$email_error=$location_error=$devicetype_error=$nearestpoint_error=$pagename_error=$usersno_error="";
    
    if($_SERVER['REQUEST_METHOD']=='POST') {

            $i=0;
            $image=$_FILES['image'];
            $name=$_FILES['image']['name'];
            $size=$_FILES['image']['size'];
            $tmp=$_FILES['image']['tmp_name'];
            $type=$_FILES['image']['type'];
            $description=$_POST['description']; 

            if(empty($_POST['fullname'])){
            
            $fullname_error="Client's Full Name Cannot Be Empty"; 
            $i++;

            } else {
                
                $fullname=$_POST['fullname']; 
            }
            
            if(empty($_POST['phoneno'])){
                $phoneno_error="Client's Phone No Cannot Be Empty";
                $i++;
            }
            else {
                $phoneno=$_POST['phoneno'];
            }
            if(empty($_POST['email'])){
                $email_error="Client's Email Cannot Be Empty";
                $i++;
            }
         
            else if(!filter_var($_POST["email"],FILTER_VALIDATE_EMAIL)) {

                $email_error="Invalid email format";
                $i++;

            } else{
                $email=$_POST["email"];
            }
            
            if(empty($_POST['location'])){

                $location_error="Client's Location Cannot Be Empty";
                $i++;
            } else  {
            $location=$_POST['location'];
            }
                
            if(empty($_POST['devicetype'])){

                $devicetype_error="Client's Device Type Cannot Be Empty";
                $i++;
            } else {

            $devicetype=$_POST['devicetype']; 
            }

            if(empty($_POST['nearestpoint'])) {

                $nearestpoint_error="Client's Nearest Point Cannot Be Empty";
                $i++;

            }else{
            $nearestpoint=$_POST['nearestpoint']; 
            }
            
            if(empty($_POST['pagename'])) {

                $pagename_error="Client's Page Name Cannot Be Empty";
                $i++;
            } else{
            $pagename=$_POST['pagename']; 

            }
            
            if(empty($_POST['usersno'])){

                $usersno_error="Client's Users No Cannot Be Empty";
                $i++;
            }
            else{
            $usersno=$_POST['usersno']; 
            }
            
            
            
            if($name!=null){

                //print random number function
                $image1=rand(0,1000000).'_'.$name;
                move_uploaded_file($tmp,"layout\\images\\".$image1);

            }else {
            $image1="";

            // Add Clients
            }if($i==0)  {

                $stmt=$connectDb->prepare("INSERT INTO clients( FullName, PhoneNo,Email,Location,DeviceType,NearestPoint,PageName,UsersNo,Description,Image) VALUES (:f,:p,:e,:l,:d,:n,:pa,:u,:des,:i)");
                $stmt->execute(array(':f'=>$fullname,':p'=>$phoneno,':e'=>$email,':l'=>$location,':d'=>$devicetype,':n'=>$nearestpoint,':pa'=>$pagename,':u'=>$usersno,':des'=>$description,':i'=>$image1));

                echo "<div class='container'>";
                $theMsg ="<div class='alert alert-success'style='margin-top:20px;'>".$stmt->rowCount(). 'Record Inserted</div>';
                redirecttohome($theMsg,'back');
                echo"</div>";
                $fullname=$phoneno=$location=$devicetype=$nearestpoint=$pagename=$usersno=$description=$name="";  
                $fullname_error=$phoneno_error=$location_error=$devicetype_error=$nearestpoint_error=$pagename_error=$usersno_error="";
            
                    
            }
}
   
    ?>
       <!--  -->
       <h1 class="text-center"> Add New Client </h1>
       
            <div class="container">
                <form class="form-horizontal  form" action="?do=Add" method="post" enctype="multipart/form-data">
                
                        <input type="hidden" class="saved" id="" name="s" value="<?php echo  $_SESSION['save']; ?>"/>
                        <div class="form-group row" >
                                <div class="col-md-2 col-sm-2 ">
                                    <label for="fullname" id="con" class="form-label">FullName</label>   
                                </div>
                                <div class=" col-md-4 col-sm-10 ">
                                    <input type="text" class="form-control " id="input"  name="fullname" value="<?php echo $fullname;?>"  placeholder="Enter Client Full Name" >
                                    <p style="color: red;" ><?php echo $fullname_error;?> </p>
                                </div>
                            
                                <div class="col-md-2 col-sm-2 ">
                                    <label for="phoneno" id="con" class="form-label">PhoneNo</label>
                                </div>
                                <div class=" col-md-4 col-sm-10 ">
                                    <input type="text" class="form-control" id="input" value="<?php echo $phoneno;?>"  name="phoneno" placeholder="Enter Client Phone No" >
                                    <p style="color: red;" ><?php echo $phoneno_error;?> </p>
                                </div>
                            
                                </div>
                                <div class="form-group row" >
                                <div class="col-md-2 col-sm-2 ">
                                    <label for="email" id="" class="form-label">Email</label>
                                </div>
                                <div class=" col-md-4 col-sm-10 ">
                                    <input type="text" class="form-control" id="input"  value="<?php echo $email;?>"  name="email" placeholder="Enter Client Email" >
                                    <p style="color: red;" ><?php echo $email_error;?> </p>
                                </div>
                                <div class="col-md-2 col-sm-2 ">
                                    <label for="location" id="" class="form-label">Location</label>
                                </div>
                                <div class=" col-md-4 col-sm-10 ">
                                    <input type="text" class="form-control" id="input"  value="<?php echo $location;?>"  name="location" placeholder="Enter Client Location" >
                                    <p style="color: red;" ><?php echo $location_error;?> </p>
                                </div>
                            
                        </div> 
                        <div class="form-group row" >
                            <div class="col-md-2 col-sm-2 ">
                                <label for="devicetype" id="con" class="form-label">DeviceType</label>
                            </div>
                            <div class=" col-md-4 col-sm-10 ">
                                <input type="text" class="form-control" id="input" value="<?php echo $devicetype;?>"  name="devicetype" placeholder="Enter Device Type" >
                                <p style="color: red;" ><?php echo $devicetype_error;?> </p>
                            </div>
                            <div class="col-md-2 col-sm-2 ">
                                <label for="nearestlocation" id="con" class="form-label">NearestPoint</label>
                            </div>
                            <div class=" col-md-4 col-sm-10 ">
                                <input type="text" class="form-control" id="input" value="<?php echo $nearestpoint;?>"  name="nearestpoint" placeholder="Enter Nearest Point" >
                                <p style="color: red;" ><?php echo $nearestpoint_error;?> </p>
                            </div>
                        </div> 
                        <div class="form-group row" >
                            <div class="col-md-2 col-sm-2 ">
                                <label for="pagename" id="con" class="form-label">PageName</label>
                            </div>
                            <div class=" col-md-4 col-sm-10 ">
                                <input type="text" class="form-control" id="input" value="<?php echo $pagename;?>"  name="pagename" placeholder="Enter Page Name">
                                <p style="color: red;" ><?php echo $pagename_error;?> </p>
                            </div>
                            <div class="col-md-2 col-sm-2">
                                <label for="usersno" id="con" class="form-label">Users No</label>
                            </div>
                            <div class=" col-md-4 col-sm-10 ">
                                <input type="text" class="form-control" id="input"  value="<?php echo $usersno;?>" name="usersno" placeholder="Enter Users No" >
                                <p style="color: red;" ><?php echo $usersno_error;?> </p>
                            </div>
                        </div> 
                        <div class="form-group row" >
                            <div class="col-md-2 col-sm-2">
                                <label for="image" id="con" class="form-label">Photo</label>
                            </div>
                            <div class=" col-md-4 col-sm-10 ">
                            <input type="file" name="image"   class="form-control" />
                            <p style="color: red;" > </p>
                            </div>
                        
                            <div class="col-md-2 col-sm-2 ">
                                <label for="description" id="con" class="form-label">Descrption</label>
                            </div>
                            <div class=" col-md-4 col-sm-10 ">
                            <textarea name="description"   class="form-control" placeholder="Enter Your Description"></textarea>
                            </div>
                    </div>
                    <input type="submit" value="Save"  id="save" class="btn btn-primary btn-lg form-btn sa"/>
                </form>
                             
                       </div>
<?php 
  }elseif($do=='Delete'){

    $clientid=isset($_GET['clientid'])&&is_numeric($_GET['clientid'])? intval($_GET['clientid']):0;
    $stmt=$connectDb->prepare("DELETE FROM clients WHERE id = :id ");
    $stmt->bindParam(":id",$clientid);
    $stmt->execute();
    header('Location:clients.php?do=Manage'); 

}elseif($do=="Edit"){  
    
   $clientid=isset($_GET['clientid'])&&is_numeric($_GET['clientid'])? intval($_GET['clientid']):0;

   if($clientid!=0){
       $_SESSION['id']= $clientid;
   }

   if($clientid!=0){
       $_SESSION['id']= $_SESSION['id'];
   }
  
    $row=getItem("*","clients","WHERE id={$_SESSION['id']}","");
    $fullname=$phoneno=$email=$location=$devicetype=$nearestpoint=$pagename=$usersno=$description=$name="";  
    $image1="";
    if(count($row)>0){

        $fullname=$row['FullName'];
        $phoneno=$row['PhoneNo'];
        $email=$row['Email'];
        $location=$row['Location'];
        $devicetype=$row['DeviceType'];
        $nearestpoint=$row['NearestPoint'];
        $pagename=$row['PageName'];
        $usersno=$row['UsersNo'];
        $description=$row['Description'];
        $image1=$row['Image'];
    }

    $name="";  
    $fullname_error=$phoneno_error=$email_error=$location_error=$devicetype_error=$nearestpoint_error=$pagename_error=$usersno_error="";
    
    if($_SERVER['REQUEST_METHOD']=='POST'){   

        $i=0; 
    
         $id=$_POST['id'];
         
           
    if(empty($_POST['fullname'])) {
    
      $fullname_error="Client's Full Name Cannot Be Empty"; 
      $fullname="";
      $i++;
    }
    
    $check=checkitem("FullName","clients",$_POST['fullname'],"id",$_SESSION['id']);
    
    if(!empty($_POST['fullname'] )&& $check==1) {
        $fullname_error="This Name Exists,Please Enter Another One "; 
        $fullname="";
        $i++;

    }if (!empty($_POST['fullname']) && $check==0) {
        
        $fullname=$_POST['fullname']; 
       
    }if(empty($_POST['phoneno'])) {

        $phoneno_error="Client's Phone No Cannot Be Empty";
        $phoneno="";
        $i++;

    } else{

        $phoneno=$_POST['phoneno'];

    }if(empty($_POST['email'])){

        $phoneno_error="Client's Email Cannot Be Empty";
        $i++;

    } else {
        $email=$_POST['email'];

    }if(!filter_var($_POST["email"],FILTER_VALIDATE_EMAIL)){

        $email_error="Invalid email format";
        $i++;
    }else {
        $email=$_POST["email"];
    }
    
    if(empty($_POST['location'])) {

        $location_error="Client's Location Cannot Be Empty";
        $location="";
        $i++;
    }
    else{
      $location=$_POST['location'];
    }
         
    if(empty($_POST['devicetype'])) {

        $devicetype_error="Client's Device Type Cannot Be Empty";
        $devicetype="";
        $i++;
    }
    else {
      $devicetype=$_POST['devicetype']; 
    }

    if(empty($_POST['nearestpoint'])){

        $nearestpoint_error="Client's Nearest Point Cannot Be Empty";
        $nearestpoint="";
        $i++;
    }
    else{
      $nearestpoint=$_POST['nearestpoint']; 
    }
    
    if(empty($_POST['pagename'])){

        $pagename_error="Client's Page Name Cannot Be Empty";
        $pagename="";
        $i++;
    }
    else  {
      $pagename=$_POST['pagename']; 
    }
    
    if(empty($_POST['usersno']))  {

        $usersno_error="Client's Users No Cannot Be Empty";
        $usersno="";
        $i++;
    } else {
      $usersno=$_POST['usersno']; 
    }
    
    if(!empty($_POST['description']))  {

        $description=$_POST['description'];
    }  

    $image=$_FILES['image'];      
    $name=$_FILES['image']['name'];

    if($name!=null){
 
    $tmp=$_FILES['image']['tmp_name'];
    $image1=rand(0,1000000).'_'.$name;
    move_uploaded_file($tmp,"layout\\images\\".$image1);
    }   
      // 
       if($i==0){
             
            $stmt=$connectDb->prepare("UPDATE clients SET FullName=?, PhoneNo=?,Email=?,Location=?,DeviceType=?,NearestPoint=?,PageName=?,UsersNo=?,Description=?,Image=? WHERE id=?");
            $stmt->execute(array($fullname,$phoneno,$email,$location,$devicetype,$nearestpoint,$pagename,$usersno,$description,$image1,$_SESSION['id']));
            echo"<div class='container'>";
            $theMsg= "<div class='alert alert-success'style='margin-top:20px'>".$stmt->rowCount(). 'Record updated</div>';
            redirecttohome($theMsg);
            echo"</div>";
            $fullname_error=$phoneno_error=$location_error=$devicetype_error=$nearestpoint_error=$pagename_error=$usersno_error="";
      }
  }
?>
<div class="container"> 
<?php
        echo"<div class='im'>";
        //if user dont have image put default image
         if(empty($row['Image'])) {
            echo"<img src='layout/images/avatar.png'  alt='' class='p-img mx-auto d-block 'id='img'  />  ";
           }
          else
             {
               echo"<img src='layout/images/".$row['Image']."'  alt='' class='p-img mx-auto d-block 'id='img'  />";
             } 
          echo"</div>";
?>
     
      <h5 id="image" class="text-center image-text" style="color:blue;cursor:pointer">Change Profile Photo</h5>

      <!--Edit Cliets -->
      <form class="form-horizontal profile-form form" action="?do=Edit" method="post" enctype="multipart/form-data">
            <input type="hidden" class="error" id="<?php echo $_SESSION['error']; ?>" name="id" value="<?php echo $clientid?>">
            <input type="file"    name="image" class="form-control image" style="display:none;" />
            <div class="form-group row" >
                <div class="col-md-2 col-sm-2 ">
                    <label for="fullname" id="con" class="form-label">FullName</label>
                </div>
                <div class=" col-md-4 col-sm-10 ">
                    <input type="text" class="form-control " id="input"  name="fullname" value="<?php echo $fullname;?>"  placeholder="Enter Client Full Name" >
                    <p style="color: red;" ><?php echo $fullname_error;?> </p>
                </div>
            
                <div class="col-md-2 col-sm-2 ">
                    <label for="phoneno" id="con" class="form-label">PhoneNo</label>
                </div>
                <div class=" col-md-4 col-sm-10 ">
                    <input type="text" class="form-control" id="input" value="<?php echo $phoneno;?>"  name="phoneno" placeholder="Enter Client Phone No" >
                    <p style="color: red;" ><?php echo $phoneno_error;?> </p>
                </div>
            </div>
            <div class="form-group row" >
                <div class="col-md-2 col-sm-2 ">
                    <label for="email" id="" class="form-label">Email</label>
                </div>
                <div class=" col-md-4 col-sm-10 ">
                    <input type="email" class="form-control" id="input"  value="<?php echo $email;?>"  name="email" placeholder="Enter Client Email" >
                    <p style="color: red;" ><?php echo $email_error;?> </p>
                </div>
                <div class="col-md-2 col-sm-2 ">
                    <label for="location" id="" class="form-label">Location</label>
                </div>
                <div class=" col-md-4 col-sm-10 ">
                    <input type="text" class="form-control" id="input"  value="<?php echo $location;?>"  name="location" placeholder="Enter Client Location" >
                    <p style="color: red;" ><?php echo $location_error;?> </p>
                </div>
            </div> 
            <div class="form-group row" >
                <div class="col-md-2 col-sm-2 ">
                    <label for="devicetype" id="con" class="form-label">DeviceType</label>
                </div>
                <div class=" col-md-4 col-sm-10 ">
                    <input type="text" class="form-control" id="input" value="<?php echo $devicetype;?>"  name="devicetype" placeholder="Enter Device Type" >
                    <p style="color: red;" ><?php echo $devicetype_error;?> </p>
                </div>
                <div class="col-md-2 col-sm-2 ">
                    <label for="nearestlocation" id="con" class="form-label">NearestPoint</label>
                </div>
                <div class=" col-md-4 col-sm-10 ">
                    <input type="text" class="form-control" id="input" value="<?php echo $nearestpoint;?>"  name="nearestpoint" placeholder="Enter Nearest Point" >
                    <p style="color: red;" ><?php echo $nearestpoint_error;?> </p>
                </div>
            </div> 
            <div class="form-group row" >
                <div class="col-md-2 col-sm-2 ">
                    <label for="pagename" id="con" class="form-label">PageName</label>
                </div>
                <div class=" col-md-4 col-sm-10 ">
                    <input type="text" class="form-control" id="input" value="<?php echo $pagename;?>"  name="pagename" placeholder="Enter Page Name">
                    <p style="color: red;" ><?php echo $pagename_error;?> </p>
                </div>
                <div class="col-md-2 col-sm-2">
                    <label for="usersno" id="con" class="form-label">Users No</label>
                </div>
                <div class=" col-md-4 col-sm-10 ">
                    <input type="text" class="form-control" id="input"  value="<?php echo $usersno;?>" name="usersno" placeholder="Enter Users No" >
                    <p style="color: red;" ><?php echo $usersno_error;?> </p>
                </div>
            </div> 
            <div class="form-group row" >
                <div class="col-md-2 col-sm-2 ">
                    <label for="description" id="con" class="form-label">Descrption</label>
                </div>
                <div class=" col-md-4 col-sm-10 ">
                <textarea name="description"   class="form-control" placeholder="Enter Your Description"></textarea>
                </div>
            </div>
            <div class="form-group  form-group-lg row">
                <div class="col-sm-offset-2 col-sm-10">
                <input type="submit" value="Save" class="btn btn-primary btn-lg "  name="save" id="save"/>
                </div>
            </div>
            
     </form>
</div>

<script src="layout/js/jquery.js"></script>  
<script>
 $('#image').click(function() {

        $('.image').click();
        })
        $('.image').change(function(){
        var data=new FormData();
        data.append('file',$('.image')[0].files[0]);
        $.ajax({
                url: 'fetch.php',
                type: 'POST',
                data: data,
                processData: false,
                contentType: false,
                success: function (data) {
                var img=$('.image').val().slice(12,$('.image').val().length);
                console.log(img);
                $('#img').attr('src','layout/images/' + img); 
    
                }
    });
    
        return false;
    }); 



</script>  

<?php  }