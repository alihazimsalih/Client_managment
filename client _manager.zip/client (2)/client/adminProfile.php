<?php
  
  /*
    Admins Profile 
    -Edit info. for admins [Username , password, email].
  */

  session_start();

  $pageTitle = "Members";

  if (isset($_SESSION['Username'])){

    include "initialize.php";

    $do = '';

    if(isset($_GET['do'])){

        $do = $_GET['do'];

    } else{

      $do = 'Mange';
    } 

    //----------------------------------------
    //--------Start Manage page members-------
    //----------------------------------------

  if ($do == 'Mange'){

    
      //=====================================
      //========Start edit page members======
      //=====================================

    } elseif ($do == 'Edit'){

        //check if get request userid is numeric and get the integer value of it.
         $userid = isset($_GET['userid']) && is_numeric($_GET['userid']) ? intval ($_GET['userid']) : 0;

        //select all data depend o this id
        $statement = $connectDb->prepare("SELECT* FROM admins WHERE UserId = ? LIMIT 1");

        //execute the query
        $statement->execute(array($userid));

        //fetch the data
        $row = $statement->fetch();

        //the row count
        $count = $statement->rowCount();
    
        //if there's such id show the form
        if ($count > 0){ ?>

            <!-- design the edit members form -->
            <h1 class="text-center" id="title"><span><img src="layout/images/edit.svg" class="image"/></span>  Edit Your Profile </h1>
            <div class="container">
                <form class ="form-horizontal" action="?do=Update" method="POST">
                <!-- start  username  field-->
                    <div class="form-group" >
                        <label class="col-sm-2 control-label" id="label-form"> Username </label>
                        <div class="col-sm-10 col-md-6">
                            <input type="text" name="username" id="style-input" class="form-control" value="<?php echo $row['UserName']?>" autocomplete="off" required="required"/>
                            <input type="hidden" name="userid" value="<?php echo $userid; ?>"/>
                        </div>
                    </div>
                <!-- end username field -->

                

                <!-- start  email  field-->
                <div class="form-group">
                        <label class="col-sm-2 control-label"  id="label-form"> Email </label>
                        <div class="col-sm-10 col-md-6">
                            <input type="email" name="email"  id="style-input" class="form-control" value="<?php echo $row['Email'] ?>" autocomplete="off" required="required"/>
                        </div>
                    </div>
                <!-- end email field -->

                <!-- start  password  field-->
                <div class="form-group">
                        <label class="col-sm-2 control-label" id="label-form"> Password </label>
                        <div class="col-sm-10 col-md-6">
                            <input type="hidden" name="oldpassword" val="<?php $row['Password'] ?>"/>
                            <input type="password" name="newpassword"  id="style-input"  class="form-control" autocomplete="new-password" require="required"/>
                        </div>
                    </div>
                <!-- end password field -->

                <!-- start  button save field-->
                <div class="form-group">
                        <div class="col-sm-10">
                        <button type="submit" class="btn btn-success" id="btn-form"> Save Information </button>
                        </div>
                    </div>
                <!-- end full name field -->
                </form>
            </div>

         <?php 
        }
      
      else{

    }
?>
      
   <?php 

   //-----------------------------------------
   //-------Start update paeg membeers--------
   //-----------------------------------------
   }elseif ($do == "Update"){

        if ($_SERVER['REQUEST_METHOD'] == 'POST'){

            echo "<h1 class='text-center' id='title-sccess' > <span><img src='layout/images/update.svg'class='image'/></span>Update </h1>";
            echo "<div class='container'>";

            $user_id     = $_POST['userid'];
            $user_name   = $_POST['username'];
            $email       = $_POST['email'];

            
            //update password
            $pass = '';

            if (empty($_POST['newpassword'])){
                $pass = $_POST['oldpassword'];
            }else{
                $pass = sha1($_POST['newpassword']);
            }

            

                //Update for members in data base.
                 $statement = $connectDb->prepare("UPDATE admins 
                                                    SET UserName = ? , Email = ? , Password =? 
                                                    WHERE UserId = ? ");

                $statement->execute(array($user_name, $email, $pass,$user_id));
                echo "<h1 class='text-center' id='title-sccess' >
                       <span><img src='layout/images/sccess.svg'class='image'/>
                    </span>Success Update </h1>";

                $_SESSION['Username'] = $_POST['username'];

           
        }else{

            echo "<div class='alert alert-success'><h1 class='text-center'>:( </h1> <div>" ;
        }

        echo "</div>";

     
     }
    


    } else{
        header('Location : sign.php');
        exit();
    }
 
?>