<?php
//fetch.php
if(isset($_FILES['file']))
{
  $image=$_FILES['file'];
  $name=$_FILES['file']['name'];
  $tmp=$_FILES['file']['tmp_name'];
  
 move_uploaded_file($tmp,"layout\\images\\".$name);
}
?>