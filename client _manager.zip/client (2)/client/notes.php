<?php

    session_start();

    if (isset($_SESSION['Username'])){

        $pageTitle = "Notes";

        include "initialize.php";

        $connection =  require_once('connection.php');

        $notes =$connection->getNotes();

        $currentNote =[
          'id'         => '',
          'title'      => '',
          'description'=> '',
        ];

        if(isset($_GET['id'])){
          $currentNote = $connection->getNoteById($_GET['id']);

        }
    }

?>



 <!-- The image and title page [Notes] -->
 <h3 class="text-center" id="title-note-page" ><span><img src="layout/images/note.svg" class="image"/></span> Notes </h3>

 <!-- form the  note [input text , textarea and button] -->
 <div class="container">

  <form class ="form-horizontal" id="new-note" action="createNote.php" method="POST" >

    <!-- The title note-->
     <div class="form-group" >
       <div class="col-sm-10 col-md-6">
         <input type="hidden" name="id" value="<?php echo $currentNote['id'] ?>">
         <input type="text" name="title" class="form-control"  autocomplete="off" 
                required="required" placeholder="Note title" value="<?php echo $currentNote['title'] ?>"/>
       </div>
      </div>
   <!-- end the title note -->

   <!-- The description note-->
   <div class="form-group">
      <div class="col-sm-10 col-md-6">
        <textarea name="description" cols="48" rows="4" 
          class="form-control" placeholder="Note description">
          <?php echo $currentNote['description'] ?>
        </textarea>
      </div>
    </div>
    <!-- end the description not -->

     <!-- Button Add note -->
     <div class="form-group">
       <div class="col-sm-10">
         <button class="btn btn-dark" > 

           <?php if ($currentNote['id']): ?>
            <i class="fa fa-edit"></i> Update Note

           <?php else: ?>
            <i class="fa fa-plus add-i"></i> New Note

           <?php endif;?>

         </button>
         </div>
      </div>
     <!-- end button add note -->

    </form>

  </div>
 


  <div class="container">
    <div class="notes">
    <?php  foreach($notes as $note): ?>
      <div class="note">
        <div class="title">
          <a href="?id=<?php echo$note['id'] ?>" > <?php echo $note['title']; ?> </a>
        </div>
        <div><?php echo $note['description']; ?></div>
        
        <small><?php echo $note['creat_date']; ?></small>

        <form action="delete.php" method="POST">
          <input type="hidden" name="id" value="<?php  echo $note['id']?>"/>
          <button class="close">x</button>
       </form>
      </div>
    <?php endforeach; ?>
    </div>
   </div>
    </div>