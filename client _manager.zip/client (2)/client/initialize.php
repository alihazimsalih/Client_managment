<?php

  //________Connect DB ______________

  include 'connectDB.php';

  //_________________________________
  //______ Directory location________
  //_________________________________

     
  $cssDir     = 'layout/css/';          // css directory.
  $javaDir    = 'layout/js/';           // java directory.
  $navBar     = 'includes/templates/';  // navbar directory. 
  $templatDir = 'includes/templates/';  // temples directory.
  $funcDir    = 'includes/function/';    // function directory.

  //________header location____________
  include $funcDir . 'function.php';   //function location.
  include $templatDir . "header.php";

  //_________navbar location___________
  //if page not view navbar [ put variable $noNavbar ='';].
  if (!isset($noNavber)){         
    include $navBar . "navbar.php";
  }

  //__________footer location__________
  include $templatDir . "footer.php";
 ?>