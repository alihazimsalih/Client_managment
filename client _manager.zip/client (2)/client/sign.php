<?php
         session_start();

         if (isset($_SESSION['Username'])){

           header('Location: clients.php');  //move the dashbord page
         }

         include "connectDB.php";
        
         //Check if user is comming from post request.
         if ($_SERVER['REQUEST_METHOD'] == 'POST'){
           $userName     = $_POST['username'];
           $password     = $_POST['password'];
     
           //Cheak user name if exist in data base.
           $statement = $connectDb->prepare("SELECT 
                                                UserId, UserName, Password
                                             FROM 
                                                 admins 
                                             WHERE
                                                 UserName = ? 
                                             AND 
                                                 Password = ? 

                                             LIMIT 1");
     
           $statement->execute(array($userName, $password));
           $row = $statement->fetch();
           $count = $statement->rowCount();
     
           // if count > 0 this mean the data base contain record about user name
           if ($count > 0){
             $_SESSION['Username'] = $userName;  //register for session
             $_SESSION['ID']       = $row['UserId'];
             header('Location: clients.php');
             exit();
           }else {
          
          }
         }
         
     ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sign in & Sign up </title>

    <!-- The CSS link -->
    <link rel="stylesheet" href="layout/css/all.min.css" />
    <ink rel="stylesheet" href="layout/css/fontawesome.min.css"/>
    <link rel="stylesheet" href="layout/css/signStyle.css"/>
  </head>
  <body>

    <div class="container">
      <div class="forms-container">
        <div class="signin-signup">


        
      
			 <!--Start form  sign in design -->
          <form action="<?php echo $_SERVER ['PHP_SELF'] ?>" class="sign-in-form"  method="POST">

		       <img src="layout/images/avatar.svg" height="150px">
           <h2 class="title">Sign in</h2>

            <div class="input-field">
              <i class="fas fa-user"></i>
              <input type="text" placeholder="Username" name="username" autocomplete="off" require="require" required="required" />
            </div>

            <div class="input-field">
              <i class="fas fa-lock"></i>
              <input type="password" placeholder="Password" name="password" autocomplete="new-password" require="required" />
            </div>

            <input type="submit" value="Login" class="btn solid" />
			   </form>
		     <!-- End design login -->


		     <!--Start form  sign up design -->
          <form  class="sign-up-form" method="post">

		        <img src="layout/images/singup.svg" height="150px">
            <h2 class="title">Sign up</h2>

            <div class="input-field">
              <i class="fas fa-user"></i>
              <input type="text" placeholder="Username" name="username" autocomplete="off" require="required" />
            </div>

            <div class="input-field">
              <i class="fas fa-envelope"></i>
              <input type="email" placeholder="Email" name="email" autocomplete="off" require="required" />
            </div>

            <div class="input-field">
              <i class="fas fa-lock"></i>
              <input type="password" placeholder="Password" name="password" autocomplete="new-password" require="required" />
            </div>

            <input type="submit" class="btn" value="Sign up" name="signup" />

          </form>

		      <!-- End design sing up -->
        </div>
      </div>
      <!-- The side session 'black' contain the title , description and button display the sing up and return the login  -->
      <div class="panels-container">
        <div class="panel left-panel">

			   <!-- Panels for the sing up description -->
          <div class="content">
            <h3>Sing up</h3>
            <p>
              Welcome admin, If you don't  register an account
			        please register the account to be able to use the application
            </p>

            <button class="btn transparent" id="sign-up-btn"> Sign up </button>

          </div>
          <img src="layout/images/log.svg" class="image"  alt="" />
        </div>

        <div class="panel right-panel">
          <div class="content">
		       <!-- Panels for the singin description -->
           <h3>Login</h3>
           <p>
             If you registered the account,
			       you can login and use the application, enter the name and password
            </p>

            <button class="btn transparent" id="sign-in-btn"> Sign in </button>
          </div>

          <img src="layout/images/register.svg" class="image" alt="" />
		    </div>
      </div>
    </div>

    <!-- Java script -->
    <script src="layout/js/sign.js"></script>

	</body>
</html>
