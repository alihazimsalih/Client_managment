<?php  
   /*
     ________Logout_________
   */

    session_start();        //start session.
    session_unset();       // unset the data.
    session_destroy();    //  Destroy the session 
    
    header('Location: sign.php');   //move the page login.
    exit();

?>