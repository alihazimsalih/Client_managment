<?php
  //_____________________________________________
  //______Connect with data base using PDO_______
  //_____________________________________________

  $dsn  = 'mysql:host=localhost;dbname=client_manager';  //data source name
  $user = 'root';
  $pass = '';

  try{

    $connectDb = new PDO($dsn, $user, $pass);
    $connectDb->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  }catch(PDOException $e ){
    echo "Falid connect data base";
    $conectDb->getMessage();
  }

 ?>