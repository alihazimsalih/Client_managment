<!DOCTYPE html>
<html>
    <head>
      <meta charset="utf-8"/>
      <title><?php getTitle(); ?></title>
      <!-- css for [Bootstarp, Fontawesome , my css] -->
      <link rel="stylesheet" href="<?php echo $cssDir;?>all.min.css"/>
      <link rel="stylesheet" href="<?php echo $cssDir;?>fontawesome.csss"/>
      <link rel="stylesheet" href="<?php echo $cssDir;?>bootstrap.min.css" />
      <link rel="stylesheet" href="<?php echo $cssDir;?>projectStyle.css"/>
    </head>
    <body>