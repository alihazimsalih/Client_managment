<?php
  include 'connectDB.php';
  
?>

<?php

  $statement = $connectDb->prepare("SELECT * FROM admins WHERE UserName=? LIMIT 1");
  $statement->execute(array($_SESSION['Username']));
  $row=$statement->fetch();
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <img src="layout/images/logo.svg" alt="website logo" hight="80px" width=80px">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mainNav" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="mainNav">
    <ul class="navbar-nav mr-auto">
      
      <li class="nav-item  active">
        <a class="nav-link" href="clients.php"> Clients Managment <span class="sr-only">(current)</span> </a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="location.php">GPS Client</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="notes.php"> Note Book </a>
      </li>

    </ul>
    <ul class="navbar-nav ml-auto">
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <?php echo $row['UserName']; ?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item"  href="adminProfile.php?do=Edit&userid=<?php echo $_SESSION['ID']; ?>">Edit Profile</a>
          <a class="dropdown-item" href="#">About</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="logout.php">Logout</a>
        </div>
      </li>

</ul>
    
  </div>
</div>
</nav>