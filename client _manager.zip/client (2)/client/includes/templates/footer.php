
      <div class="footer">
        
        </div>
        <!-- java script for [bootstarp , JQuery, my java script] -->
        <script src="<?php echo $javaDir;?>jquery-3.5.1.min.js"></script>
        <script src="<?php echo $javaDir;?>bootstrap.min.js"></script>  
      </body>
  </html>
  