<?php

  /*
    - The title function for the page
    - Get the name page .
  */

   function getTitle(){

    global $pageTitle;

    if (isset($pageTitle)){

        echo $pageTitle;
      }else{

        echo "No page title";
      }
    }

/*Get All records from data base function*/
function getAll($field,$tablename,$where=Null,$and=Null,$orderBy,$ordering='DESC')
{     global $connectDb;
  
     $stmt=$connectDb->prepare("SELECT $field FROM $tablename $where $and ORDER BY $orderBy $ordering ");
     $stmt->execute();
     $rows=$stmt->fetchAll();
     return $rows;
     
     
}
/*Get All records from data base function*/
function getItem($field,$tablename,$where,$and=Null)
{     global $connectDb;
  
     $stmt=$connectDb->prepare("SELECT $field FROM $tablename $where $and ");
     $stmt->execute();
     $rows=$stmt->fetch();
     return $rows;
     
     
}

/*
 *Redirect to other page 
 */
function redirecttohome($theMsg,$url=null,$second=3)
{ if($url===null)
   {
     $url='clients.php';
     $link='Home page';
   }
   else
   {
     if(isset($_SERVER['HTTP_REFERER'])&& $_SERVER['HTTP_REFERER']!=='')
     {
       $url=$_SERVER['HTTP_REFERER'];
       $link='Previous page';
     }
      
     else
     {
       $url="clients.php";
       $link='Home page';
     }

   }
  

  echo $theMsg;
  echo "<div class='alert alert-info'>You will be redirected to $link after $second seconds.</div>";
  header("refresh:$second;url=$url");
  exit();
}


//checks if item exists in database
function checkitem($select,$from,$value)
{
  global $connectDb;
  $statement=$connectDb->prepare("SELECT $select FROM $from WHERE $select= ? ");
  $statement->execute(array($value));
  $count=$statement->rowCount();
 return $count;
}
//checks if item exists in database but not this item
?>
